var mysql = require('mysql');
var conn = mysql.createConnection({
    host: 'localhost',
    user: 'websocket',
    password: 'websocket',
    database:'websocket',
    port: 3306
});
conn.connect();

conn.end();